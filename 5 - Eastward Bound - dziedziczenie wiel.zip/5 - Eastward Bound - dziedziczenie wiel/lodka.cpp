#include "lodka.h"

Lodka::Lodka(float w){
    wypornosc = w;
}

float Lodka::getWypornosc(){
    return wypornosc;
};

void Lodka::setWypornosc(float w){
    wypornosc = w;
}

std::string Lodka::info(){
    std::string wynik = "Lodka: ";
    wynik+= " ma wypornosc " + std::to_string(wypornosc);
    return wynik;
}