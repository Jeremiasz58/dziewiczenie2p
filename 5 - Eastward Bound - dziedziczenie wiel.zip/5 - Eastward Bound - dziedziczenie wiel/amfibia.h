#pragma once
#include "auto.h"
#include "lodka.h"


class Amfibia : public Auto, public Lodka{
    private :
        int silaRazenia;
    public :
        Amfibia(int ik, float w, int sr);
        std::string info();
};