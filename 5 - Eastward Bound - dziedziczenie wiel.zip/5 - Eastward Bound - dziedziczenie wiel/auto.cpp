#include "auto.h"


Auto::Auto(int ik){
    iloscKol = ik;
}

void Auto::setIloscKol(int ik){
    iloscKol = ik;
}

int Auto::getIloscKol(){
    return iloscKol;
}

std::string Auto::info(){
    std::string result = "Auto: ";
    result = " ma kola " + std::to_string(iloscKol);
}