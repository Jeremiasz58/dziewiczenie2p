#include <iostream>
#include "amfibia.h"

using namespace std;

int main(int argc, char const *argv[])
{
    Amfibia amrt17(4, 5.6, 1400);
    cout<<amrt17.info();

    return 0;

    // za tydz zadanko
}
