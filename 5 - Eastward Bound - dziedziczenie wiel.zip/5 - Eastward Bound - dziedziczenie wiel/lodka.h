#pragma once
#include <string>

class Lodka{
    protected :
        float wypornosc;
    public :
        Lodka(float w);
        void setWypornosc(float w);
        float getWypornosc();
        std::string info();
};