#pragma once
#include <iostream>
#include <string>



class Auto{
    protected :
        int iloscKol;

    public : 
        Auto(int k);
        int getIloscKol();
        std::string info();
        void setIloscKol(int ik);
};