#include "amfibia.h"
#include <string>

Amfibia::Amfibia(int ik, float w, int sr):Auto(ik),Lodka(w){
    silaRazenia = sr;

}

std::string Amfibia::info(){
    std::string result = " To jest amfibia o sile razenia " + std::to_string(silaRazenia);
    result += " i sklada sie z :\n";
    result+=Auto::info();
    result+="\n";
    result+=Lodka::info();
    return result;
}